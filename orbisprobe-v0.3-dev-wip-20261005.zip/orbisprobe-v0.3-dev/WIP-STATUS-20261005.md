# OrbisProbe — WIP-Übergabe 2026-10-05

1:1-Snapshot des Arbeitsverzeichnisses `/home/hermes/tools/orbisprobe-v0.2-dev`
zum Weitercoden und Anpassen.

- Version: `0.3.0.dev0` (`pyproject.toml`)
- Branch: `v0.2-live22`
- HEAD: `52fe5576d36fd760f7a3a31afb280b1ffdeb960c` — "orbisprobe: add v0.3 lead and closure-cost research scheduler"
- Enthalten: komplette Git-History (`.git`, 592 Objekte) + Working Tree **inklusive uncommitted WIP**

## Working-Tree-WIP (uncommitted, enthalten)

Modified (2 Dateien, +20/−1 Zeilen):
- `orbisprobe/cli.py` — `evidence-pass`-Subcommand verdrahtet
- `orbisprobe/live/attach.py` — Greeting-Firmware: akzeptiert `fw_dec`/`fw_hex` neben `fw` (Konsistenzprüfung)

Untracked:
- `orbisprobe/evidence_pass/` — neues Modul (model, plan, runner, journal, builder, verify, review, metrics, rebuild, remediation, direction, manifest, cli)
- `orbisprobe/live/trace_client.py`
- `orbisprobe/live/payload/ps4_live1_trace_payload.c`, `ps4_live2_trace_payload.c`
- `tests/evidence_pass_support.py`, `tests/test_evidence_pass_units.py`, `tests/test_evidence_pass_regressions.py`, `tests/fixtures/evidence_pass/`

## Test-Status (Stand dieses Snapshots)

- Voll: **654 passed** — verifiziert am 2026-10-05 im Original-Repo mit der Umgebung unten.
- Ohne Backend-Envs (`.backend-envs/` fehlt): 568 passed / 19 failed / 67 skipped — die Ausfälle sind reine Umgebungsfolgen (angr-, Ghidra-, Triton-Backends nicht verfügbar), kein Code-Regress.
- WIP-Tests des neuen Moduls: `tests/test_evidence_pass_units.py` + `tests/test_evidence_pass_regressions.py` → 28 passed.

## Testumgebung (exakte Stolpersteine, 2026-10-05 verifiziert)

```bash
export ORBISPROBE_GHIDRA_HOME=/home/hermes/tools/ghidra_12.1.3_PUBLIC
export ORBISPROBE_JAVA_HOME=/home/hermes/tools/jdk25/jdk-25.0.4.1+1   # vollständiges JDK nötig
export TMPDIR=/tmp/op-tmp                                            # Pfad darf KEIN Element mit '.' enthalten
export ORBISPROBE_ANGR_PYTHON=<repo>/.backend-envs/angr/bin/python
export ORBISPROBE_TRITON_PYTHON=<repo>/.backend-envs/triton/bin/python
python3 -m pytest -q
```

Belegte Ursachen der 6 Ghidra-Ausfälle (ohne obige Variablen):

1. Java-Auflösung: Default-Kandidat `tools/localroot/usr/lib/jvm/java-21-openjdk-amd64` ist **JRE-only** (kein `javac`, `bin/` enthält nur java/jpackage/keytool/rmiregistry) → Ghidra braucht ein volles JDK.
2. Ghidra `AnalyzeHeadless` lehnt Projektpfade ab, die ein mit `.` beginnendes Pfadelement enthalten. Mit `TMPDIR=/home/hermes/.hermes/cache/scratch/...` bricht es ab mit:
   `ERROR Abort due to Headless analyzer error: Path element starting with '.' is not permitted (HeadlessAnalyzer) java.lang.IllegalArgumentException: Path element starting with '.' is not permitted`

Mit beiden Fixes: `tests/test_ghidra_backend.py` → 27 passed.

## Bewusst NICHT enthalten (reproduzierbar bzw. Artefakte)

- `.backend-envs/` (297 MB: angr 210 MB, triton 87 MB) — Neuaufbau:
  `uv venv --python 3.12 .backend-envs/angr` und
  `uv pip install --python .backend-envs/angr/bin/python 'angr==9.2.184' 'pycparser==2.22'`
  (siehe `docs/M2A-BACKENDS.md`, Abschnitt Development environment; Triton analog, `docs/M2B-REPORT.md` Abschnitt "Reproducing")
- `evidence/` (8,4 MB Laufartefakte, gitignored)
- `build/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `*.egg-info/`

## Integrität / Rückbau

- Entpacken: `unzip orbisprobe-v0.3-dev-wip-20261005.zip` → Ordner `orbisprobe-v0.3-dev/`
- `git status --short` muss exakt die WIP-Liste oben zeigen (plus diese Datei als untracked).
- SHA-256 des Zips steht in der Chat-Nachricht.
- Hinweis: Hermes-Umgebung hatte `capstone 5.0.7`, `pyproject.toml` pinnt `capstone==5.0.9` — Suite lief damit trotzdem vollständig grün.
